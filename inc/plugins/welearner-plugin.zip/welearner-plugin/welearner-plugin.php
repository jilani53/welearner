<?php
/*
Plugin Name: Welearner Plugin
Plugin URI: https://banyanthemes.com/
Description: This plugin is developed to build Welaerner theme features.
Author: Jilani Ahmed
Version: 1.5
Author URI: https://banyanthemes.com/
*/

require_once 'inc/cpt.php';
require_once 'inc/metabox.php';
require_once 'inc/widget.php';
