<?php
/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */

function welearner_widgets_init() {

    register_sidebar(
        array(
            'name'          => esc_html__( 'Sidebar', 'welearner' ),
            'id'            => 'sidebar-1',
            'description'   => esc_html__( 'Add widgets here.', 'welearner' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title">',
            'after_title'   => '</h2>',
        )
    );
    register_sidebar(
        array(
            'name'          => esc_html__( 'Home Widgets', 'welearner' ),
            'id'            => 'home-area',
            'description'   => esc_html__( 'Add home widgets here.', 'welearner' )
        )
    );

    register_sidebar(array(
        'name'          => esc_html__('Footer Widgets', 'welearner'),
        'id'            => 'footer-area',
        'description'   => esc_html__('Footer widgets position.', 'welearner')
    ));

    /**
     * Hero section
     */
    class welearnerHero extends WP_Widget {
        
        public function __construct(){
            $widget_details = array(
                'classname' => 'welearnerHero',
                'description' => esc_html__( 'Hero section element.','welearner' )
            );
            parent::__construct( 'welearnerHero', esc_html__( '&#9733; Hero Section','welearner' ) , $widget_details );
        }

        // Render Widget / Frontend
        function widget($args, $instance) { ?>
            
            <div class="welearner-hero">
                <div class="container">
                    <div class="row">
                        
                        <div class="main-menu">     
                            <nav class="navbar navbar-expand-lg navbar-light btco-hover-menu">                           
                            
                                <a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
                                    <?php 
                                    
                                    $custom_logo_id = get_theme_mod( 'custom_logo' );							

                                    $logo = wp_get_attachment_image_src( $custom_logo_id , 'full' );
                                    if ( has_custom_logo() ) {
                                        echo '<img src="' . esc_url( $logo ) . '" class="d-inline-block align-top" alt="' . get_bloginfo( 'name' ) . '">';
                                    } else {
                                        echo '<h1>'. get_bloginfo( 'name' ) .'</h1>';
                                    }
                                    
                                    ?>								
                                </a>

                                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="navbar-toggler-icon"></span>
                                </button>

                                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            
                                    <?php /* Primary navigation */

                                    wp_nav_menu( 
                                        array(
                                            'theme_course' => 'primary',
                                            'depth' => 4,
                                            'container' => false,
                                            'menu_class' => 'navbar-nav ml-auto welearner-nav',
                                            'fallback_cb'  => 'welearner_primary_menu_fallback',
                                            //Process nav menu using our custom nav walker
                                            'walker' => new WP_Bootstrap_Navwalker(),                       
                                        )
                                    );

                                    ?>							                                                              
                                
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>

                <div class="main-banner">
                    <div class="hvrbox">
                        <img src="<?php echo esc_url($instance['image_uri']); ?>" alt="" class="hvrbox-layer_bottom">
                        <div class="hvrbox-layer_top">
                            <div class="overlay-text">
                                <h1><?php echo wp_kses( $instance['title'], 'allowed_html' ); ?></h1>
                                <p><?php echo wp_kses( $instance['desc'], 'allowed_html' ); ?></p>
                                <div class="col-md-7 welearner-search">
                                    <div class="input-group mb-3">
                                        <input type="text" class="form-control" placeholder="<?php esc_attr_e( 'What do you want to learn?', 'welearner' ); ?>" aria-label="Recipient's username" aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button type="submit" class="input-group-text search-btn" id="basic-addon2"><?php esc_html_e( 'Search', 'welearner' ); ?></button>
                                        </div>
                                    </div>
                                </div>							
                            </div>
                        </div>				
                    </div>
                </div>
            </div>

        <?php
        }

        function update($new_instance, $old_instance) {
            $instance = $old_instance;
            $instance['title'] =  $new_instance['title'] ;
            $instance['desc'] =  $new_instance['desc'] ;
            $instance['image_uri'] = $new_instance['image_uri'];
            return $instance;
        }

        // Back-end Fields
        function form($instance) { 
            
            $title = isset( $instance['title'] ) ? $instance['title']: '';
            $desc = isset( $instance['desc'] ) ? $instance['desc']: '';
            $image_uri = isset( $instance['image_uri'] ) ? $instance['image_uri']: ''; ?>

            <p>
                <label for="<?php echo $this->get_field_id('title'); ?>"><?php esc_html_e( 'Title', 'welearner' ); ?></label><br />
                <input type="text" name="<?php echo $this->get_field_name('title'); ?>" id="<?php echo $this->get_field_id('title'); ?>" value="<?php echo wp_kses( $title, 'allowed_html' ); ?>" class="widefat" />
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('desc'); ?>"><?php esc_html_e( 'Description', 'welearner' ); ?></label><br />
                <textarea name="<?php echo $this->get_field_name('desc'); ?>" id="<?php echo $this->get_field_id('desc'); ?>" class="widefat"><?php echo wp_kses( $desc, 'allowed_html' ); ?></textarea>
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_id( 'image_uri' )); ?>"><?php esc_html_e( 'Background Image', 'welearner' ); ?></label>
                <img class="<?php echo esc_attr( $this->id ); ?>_img" src="<?php (!empty($instance['image_uri'])) ? $instance['image_uri'] : ''; ?>" />
                <input type="text" class="widefat <?php echo esc_attr( $this->id ); ?>_url" name="<?php echo esc_attr( $this->get_field_name( 'image_uri' )); ?>" value="<?php echo esc_attr( $image_uri ); ?>" />
                <input type="button" id="<?php echo esc_attr( $this->id ); ?>" class="button button-primary js_custom_upload_media" value="Upload Image" />
            </p>

        <?php
        }
    }

    /**
     * Testimonial section
     */
    class welearnerTestimonial extends WP_Widget{    
            
        public function __construct() {
            $widget_details = array(
                'classname' => 'welearnerTestimonial',
                'description' => esc_html__( 'Testimonial section element.','welearner' )
            );
            parent::__construct( 'welearnerTestimonial', esc_html__( '&#9733; Testimonial Section','welearner' ) , $widget_details );
        }
    
        // Render Widget / Frontend
        public function widget( $args, $instance ) { 
            
            // Variable defind
            $title = isset( $instance['title'] ) ? $instance['title']: '';
            $desc = isset( $instance['desc'] ) ? $instance['desc']: '';
            $inputbox = isset( $instance['inputbox'] ) ? $instance["inputbox"] : ''; ?>

            <div class="welearner-testimonial">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 section-header">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="welearner-title">
                                    <?php echo wp_kses( $title, 'allowed_html' ); ?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="welearner-desc">
                                        <?php echo wp_kses( $desc, 'allowed_html' ); ?>
                                    </div>
                                </div>
                            </div>
                        </div>				

                        <div class="testimonial-carousel">
                            <?php for( $i=1; $i<=$inputbox; $i++ ) { 
                                
                                // Variable defind
                                $image_uri = isset( $instance["image_uri$i"] ) ? $instance["image_uri$i"] : '' ;     
                                $name = isset( $instance["name$i"] ) ? $instance["name$i"] : '' ;
                                $designation = isset( $instance["designation$i"] ) ? $instance["designation$i"] : '' ;     
                                $comment = isset( $instance["comment$i"] ) ? $instance["comment$i"] : '' ;  
                                
                                ?>
                                <div class="single-member">
                                    <?php if( $image_uri ): ?><img src="<?php echo esc_url($image_uri); ?>" alt="<?php echo esc_attr($name); ?>"><?php endif; ?>
                                    <?php if( $name ): ?><span class="name"><?php echo esc_html($name); ?></span><?php endif; ?>
                                    <?php if( $designation ): ?><span class="designation"><?php echo esc_html($designation); ?></span><?php endif; ?>
                                    <?php if( $comment ): ?><p class="comment"><?php echo wp_kses( $comment, 'allowed_html' ); ?></p><?php endif; ?>
                                </div>
                            <?php } ?>
                        </div>
                        
                    </div>
                </div>
            </div>

        <?php	
        }    
        
        // Update inputed data
        public function update( $new_instance, $old_instance ) {  
            return $new_instance;
        }
        
        // Back-end Fields
        public function form( $instance ) {

            // Variable defind
            $title = isset( $instance['title'] ) ? $instance['title']: ''; 
            $desc = isset( $instance['desc'] ) ? $instance["desc"] : '';
            $inputbox = isset( $instance['inputbox'] ) ? $instance["inputbox"] : ''; ?>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>"><b><?php esc_html_e( "Title","welearner" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "title" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('desc'); ?>"><?php esc_html_e( 'Description', 'welearner' ); ?></label><br />
                <textarea name="<?php echo $this->get_field_name('desc'); ?>" id="<?php echo $this->get_field_id('desc'); ?>" class="widefat"><?php echo wp_kses( $desc, 'allowed_html'); ?></textarea>
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>"><b><?php esc_html_e( "How many testimonial would you want? & hit save.","welearner" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "inputbox" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" type="text" value="<?php echo esc_attr( $inputbox ); ?>" />
            </p>

            <?php
            
            for( $i=1; $i<=$inputbox; $i++ ) {

                // Variable defind
                $image_uri = isset( $instance["image_uri$i"] ) ? $instance["image_uri$i"] : '' ;     
                $name = isset( $instance["name$i"] ) ? $instance["name$i"] : '' ;
                $designation = isset( $instance["designation$i"] ) ? $instance["designation$i"] : '' ;     
                $comment = isset( $instance["comment$i"] ) ? $instance["comment$i"] : '' ;     

                ?>  
                <!-- Member fields -->
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_id( "image_uri$i" )); ?>"><?php esc_html_e( 'Background Image', 'welearner' ); ?></label>
                    <img class="<?php echo esc_attr( $this->id.$i ); ?>_img" src="<?php echo esc_url( $image_uri ); ?>" />
                    <input type="text" class="widefat <?php echo esc_attr( $this->id.$i ); ?>_url" name="<?php echo esc_attr( $this->get_field_name( "image_uri$i" )); ?>" value="<?php echo esc_attr( $image_uri ); ?>" />
                    <input type="button" id="<?php echo esc_attr( $this->id.$i ); ?>" class="button button-primary js_custom_upload_media" value="<?php esc_html_e( 'Upload Image', 'welearner' ); ?>" />
                </p>
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "name$i" ) ); ?>"><?php echo esc_html( 'Name', 'welearner' ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "name$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "name$i" ) ); ?>" type="text" value="<?php echo esc_attr( $name ); ?>" />
                </p>
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "designation$i" ) ); ?>"><?php echo esc_html( 'Designation', 'welearner' ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "designation$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "designation$i" ) ); ?>" type="text" value="<?php echo esc_attr( $designation ); ?>" />
                </p>
                <p>
                    <label for="<?php echo $this->get_field_id("comment$i"); ?>"><?php esc_html_e( 'Comment', 'welearner' ); ?></label><br />
                    <textarea name="<?php echo $this->get_field_name("comment$i"); ?>" id="<?php echo $this->get_field_id("comment$i"); ?>" class="widefat"><?php echo wp_kses( $comment, 'allowed_html' ); ?></textarea>
                </p>
            
            <?php 
            }			
        }
    }

    /**
     * Team Member section
     */
    class welearnerTeamMember extends WP_Widget{    
            
        public function __construct() {
            $widget_details = array(
                'classname' => 'welearnerTeamMember',
                'description' => esc_html__( 'Team Member section element.','welearner' )
            );
            parent::__construct( 'welearnerTeamMember', esc_html__( '&#9733; Team Member Section','welearner' ) , $widget_details );
        }
    
        // Render Widget / Frontend
        public function widget( $args, $instance ) { 	
            
            // Variable defind
            $title = isset( $instance['title'] ) ? $instance['title']: '';
            $desc = isset( $instance['desc'] ) ? $instance['desc']: '';	
            $inputbox = isset( $instance['inputbox'] ) ? $instance["inputbox"] : ''; ?>

            <div class="welearner-team-member">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 section-header">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="welearner-title">
                                        <?php echo wp_kses( $title, 'allowed_html' ); ?>
                                    </div>
                                    <div class="welearner-desc">
                                        <?php echo wp_kses( $desc, 'allowed_html' ); ?>
                                    </div>
                                </div>							
                            </div>
                        </div>				

                        <div class="team-carousel">
                            <?php for( $i=1; $i<=$inputbox; $i++ ) { 
                                
                                $image_uri = isset( $instance["image_uri$i"] ) ? $instance["image_uri$i"] : '' ;
                                $name = isset( $instance["name$i"] ) ? $instance["name$i"] : '' ;
                                $designation = isset( $instance["designation$i"] ) ? $instance["designation$i"] : '' ;         
                                $fbook = isset( $instance["fbook$i"] ) ? $instance["fbook$i"] : '' ;         
                                $linkedin = isset( $instance["linkedin$i"] ) ? $instance["linkedin$i"] : '' ;         
                                $twitter = isset( $instance["twitter$i"] ) ? $instance["twitter$i"] : '' ; ?>

                                <div class="single-member">
                                    <div class="image-container">
                                        <img src="<?php echo esc_url($image_uri); ?>" alt="<?php echo esc_attr($name); ?>">

                                        <?php if( $fbook || $linkedin || $twitter ): ?>
                                        <div class="member-social">
                                            <?php if( $fbook ): ?><a href="<?php echo esc_url($fbook); ?>"><i class="lab la-facebook-f"></i></a><?php endif; ?>
                                            <?php if( $linkedin ): ?><a href="<?php echo esc_url($linkedin); ?>"><i class="lab la-linkedin-in"></i></a><?php endif; ?>
                                            <?php if( $twitter ): ?><a href="<?php echo esc_url($twitter); ?>"><i class="lab la-twitter"></i></a><?php endif; ?>
                                        </div>
                                        <?php endif; ?>

                                    </div>

                                    <div class="member-content">
                                        <?php if( $name ): ?><span class="name"><?php echo esc_html($name); ?></span><?php endif; ?>
                                        <?php if( $designation ): ?><span class="designation"><?php echo esc_html($designation); ?></span><?php endif; ?>
                                    </div>
                                </div>

                            <?php } ?>
                        </div>
                        
                    </div>
                </div>
            </div>

        <?php	
        }    
        
        // Update inputed data
        public function update( $new_instance, $old_instance ) {  
            return $new_instance;
        }
        
        // Back-end Fields
        public function form( $instance ) {

            // Variable defind
            $title = isset( $instance['title'] ) ? $instance['title']: ''; 
            $desc = isset( $instance['desc'] ) ? $instance["desc"] : '' ;
            $inputbox = isset( $instance['inputbox'] ) ? $instance["inputbox"] : ''; ?>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>"><b><?php esc_html_e( "Title","welearner" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "title" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('desc'); ?>"><?php esc_html_e( 'Description', 'welearner' ); ?></label><br />
                <textarea name="<?php echo $this->get_field_name('desc'); ?>" id="<?php echo $this->get_field_id('desc'); ?>" class="widefat"><?php echo wp_kses( $desc, 'allowed_html' ); ?></textarea>
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>"><b><?php esc_html_e( "How many social field would you want? & hit save.","welearner" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "inputbox" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" type="text" value="<?php echo esc_attr( $inputbox ); ?>" />
            </p>

            <?php
            
            for( $i=1; $i<=$inputbox; $i++ ) {

                // Variable defind
                $image_uri = isset( $instance["image_uri$i"] ) ? $instance["image_uri$i"] : '' ;     
                $name = isset( $instance["name$i"] ) ? $instance["name$i"] : '' ;
                $designation = isset( $instance["designation$i"] ) ? $instance["designation$i"] : '' ;         
                $fbook = isset( $instance["fbook$i"] ) ? $instance["fbook$i"] : '' ;         
                $linkedin = isset( $instance["linkedin$i"] ) ? $instance["linkedin$i"] : '' ;         
                $twitter = isset( $instance["twitter$i"] ) ? $instance["twitter$i"] : '' ;         

                ?>  
                <!-- Member fields -->
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_id( "image_uri$i" )); ?>"><?php esc_html_e( 'Background Image', 'welearner' ); ?></label>
                    <img class="<?php echo esc_attr( $this->id.$i ); ?>_img" src="<?php echo esc_url( $image_uri ); ?>" />
                    <input type="text" class="widefat <?php echo esc_attr( $this->id.$i ); ?>_url" name="<?php echo esc_attr( $this->get_field_name( "image_uri$i" )); ?>" value="<?php echo esc_attr( $image_uri ); ?>" />
                    <input type="button" id="<?php echo esc_attr( $this->id.$i ); ?>" class="button button-primary js_custom_upload_media" value="<?php esc_html_e( 'Upload Image', 'welearner' ); ?>" />
                </p>
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "name$i" ) ); ?>"><?php echo esc_html( 'Name', 'welearner' ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "name$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "name$i" ) ); ?>" type="text" value="<?php echo esc_attr( $name ); ?>" />
                </p>
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "designation$i" ) ); ?>"><?php echo esc_html( 'Designation', 'welearner' ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "designation$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "designation$i" ) ); ?>" type="text" value="<?php echo esc_attr( $designation ); ?>" />
                </p>
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "fbook$i" ) ); ?>"><?php echo esc_html( 'Facebook URL', 'welearner' ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "fbook$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "fbook$i" ) ); ?>" type="text" value="<?php echo esc_attr( $fbook ); ?>" />
                </p>
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "linkedin$i" ) ); ?>"><?php echo esc_html( 'Linkedin', 'welearner' ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "linkedin$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "linkedin$i" ) ); ?>" type="text" value="<?php echo esc_attr( $linkedin ); ?>" />
                </p>
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "twitter$i" ) ); ?>"><?php echo esc_html( 'Twitter', 'welearner' ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "twitter$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "twitter$i" ) ); ?>" type="text" value="<?php echo esc_attr( $twitter ); ?>" />
                </p>
                        
            <?php 
            }			
        }
    }

    /**
     * Blog section
     */
    class welearnerBlog extends WP_Widget{    
            
        public function __construct() {
            $widget_details = array(
                'classname' => 'welearnerBlog',
                'description' => esc_html__( 'Blog section element.','welearner' )
            );
            parent::__construct( 'welearnerBlog', esc_html__( '&#9733; Blog Section','welearner' ) , $widget_details );
        }
    
        // Render Widget / Frontend
        public function widget( $args, $instance ) { 
                
            // Variable defind
            $title = isset( $instance['title'] ) ? $instance['title']: '';
            $max_post = isset( $instance['max_post'] ) ? $instance['max_post']: 3;

            // Latest posts
            $latest_post = new WP_Query( 
                array( 
                    'posts_per_page' => $max_post, 
                    'post_type' => 'post', 
                    'order' => 'DESC',
                    'post__not_in' => get_option( 'sticky_posts' )
                ) 
            );
                
            ?>

            <div class="welearner-blog">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 section-header">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="welearner-title">
                                        <?php echo wp_kses( $title, 'allowed_html' ); ?>
                                    </div>
                                </div>							
                            </div>
                        </div>

                        <?php  //SHOW the posts
                        
                        if( $latest_post -> have_posts() ) :
                            while ( $latest_post -> have_posts() ): $latest_post -> the_post(); ?>                        
                                
                            <div class="col-lg-4 single-post">
                                <?php the_post_thumbnail( '', [ 'class' => 'home-thumbnail' ] ) ?>
                                <h2><?php the_title(); ?></h2>
                                <a href="<?php the_permalink(); ?>"><?php esc_attr_e( 'Read Blog', 'welearner' )?></a>
                            </div>
                                
                            <?php          
                            endwhile;
                            wp_reset_postdata();
                        else:
                            echo "<br>";
                            esc_html_e( 'There has post.','welearner' );                     
                        endif; ?>
                                                
                    </div>
                </div>
            </div>

        <?php	
        }    
        
        // Update inputed data
        public function update( $new_instance, $old_instance ) {  
            return $new_instance;
        }
        
        // Back-end Fields
        public function form( $instance ) {

            // Variable defind
            $title = isset( $instance['title'] ) ? $instance['title']: ''; 
            $max_post = isset( $instance['max_post'] ) ? $instance["max_post"] : 3 ; ?>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>"><b><?php esc_html_e( "Title","welearner" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "title" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
            </p>		
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "max_post" ) ); ?>"><b><?php esc_html_e( "How many post would you want? & hit save.","welearner" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "max_post" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "max_post" ) ); ?>" type="text" value="<?php echo esc_attr( $max_post ); ?>" />
            </p>

            <?php		
        }
    }

    /**
     * CTA section
     */
    class welearnerCta extends WP_Widget{    
            
        public function __construct() {
            $widget_details = array(
                'classname' => 'welearnerCta',
                'description' => esc_html__( 'CTA section element.','welearner' )
            );
            parent::__construct( 'welearnerCta', esc_html__( '&#9733; CTA Section','welearner' ) , $widget_details );
        }
    
        // Render Widget / Frontend
        public function widget( $args, $instance ) { 

            $inputbox = isset( $instance['inputbox'] ) ? $instance["inputbox"] : '' ;

            ?>

            <div class="welearner-cta">
                <div class="container">
                    <div class="row">
                        
                        <?php for( $i=1; $i<=$inputbox; $i++ ) { 
                            
                            $title = isset( $instance["title$i"] ) ? $instance["title$i"] : '' ;
                            $desc = isset( $instance["desc$i"] ) ? $instance["desc$i"] : '' ;     
                            $btn_text = isset( $instance["btn_text$i"] ) ? $instance["btn_text$i"] : '' ;     
                            $btn_url = isset( $instance["btn_url$i"] ) ? $instance["btn_url$i"] : '' ;     
                            $bg_color = isset( $instance["bg_color$i"] ) ? $instance["bg_color$i"] : '#FFE2E2' ; 
                            
                            ?>
                            <div class="col-lg-6">
                                <div class="single-cta" style="background: <?php echo esc_attr( $bg_color ); ?>;">								
                                    <?php if( $title ): ?><h2 class="title"><?php echo wp_kses( $title, 'allowed_html' ); ?></h2><?php endif; ?>
                                    <?php if( $desc ): ?><p class="desc"><?php echo wp_kses( $desc, 'allowed_html' ); ?></p><?php endif; ?>
                                    <?php if( $btn_text ): ?><a href="<?php echo esc_url($btn_url); ?>" class="cta-btn"><?php echo esc_html($btn_text); ?></a><?php endif; ?>
                                </div>
                            </div>
                        <?php } ?>
                        
                    </div>
                </div>
            </div>

        <?php	
        }    
        
        // Update inputed data
        public function update( $new_instance, $old_instance ) {  
            return $new_instance;
        }
        
        // Back-end Fields
        public function form( $instance ) {

            // Variable defind
            $inputbox = isset( $instance['inputbox'] ) ? $instance["inputbox"] : '' ; ?>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>"><b><?php esc_html_e( "How many CTA would you want? & hit enter.","welearner" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "inputbox" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" type="text" value="<?php echo esc_attr( $inputbox ); ?>" />
            </p>

            <?php
            
            for( $i=1; $i<=$inputbox; $i++ ) {

                // Variable defind     
                $title = isset( $instance["title$i"] ) ? $instance["title$i"] : '' ;
                $desc = isset( $instance["desc$i"] ) ? $instance["desc$i"] : '' ;     
                $btn_text = isset( $instance["btn_text$i"] ) ? $instance["btn_text$i"] : '' ;     
                $btn_url = isset( $instance["btn_url$i"] ) ? $instance["btn_url$i"] : '' ;     
                $bg_color = isset( $instance["bg_color$i"] ) ? $instance["bg_color$i"] : '#FFE2E2' ;     

                ?>  
                <!-- fields -->	
                <p><b><?php esc_html_e( "CTA $i", "welearner" ); ?></b><hr/></p>		
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "title$i" ) ); ?>"><?php echo esc_html( 'Title', 'welearner' ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "title$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "title$i" ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
                </p>
                <p>
                    <label for="<?php echo $this->get_field_id("desc$i"); ?>"><?php esc_html_e( 'Description', 'welearner' ); ?></label><br />
                    <textarea name="<?php echo $this->get_field_name("desc$i"); ?>" id="<?php echo $this->get_field_id("desc$i"); ?>" class="widefat"><?php echo $instance["desc$i"]; ?></textarea>
                </p>
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "btn_text$i" ) ); ?>"><?php echo esc_html( 'Button Text', 'welearner' ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "btn_text$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "btn_text$i" ) ); ?>" type="text" value="<?php echo esc_attr( $btn_text ); ?>" />
                </p>
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "btn_url$i" ) ); ?>"><?php echo esc_html( 'Button URL', 'welearner' ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "btn_url$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "btn_url$i" ) ); ?>" type="text" value="<?php echo esc_attr( $btn_url ); ?>" />
                </p>			
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "bg_color$i" ) ); ?>"><?php echo esc_html( 'Background Color Code EX: #FFE2E2', 'welearner' ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "bg_color$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "bg_color$i" ) ); ?>" type="color" value="<?php echo esc_attr( $bg_color ); ?>" />
                </p>			
            
            <?php 
            }			
        }
    }

    /**
     * Counter section
     */
    class welearnerCounter extends WP_Widget{    
            
        public function __construct() {
            $widget_details = array(
                'classname' => 'welearnerCounter',
                'description' => esc_html__( 'Counter section element.','welearner' )
            );
            parent::__construct( 'welearnerCounter', esc_html__( '&#9733; Counter Section','welearner' ) , $widget_details );
        }
    
        // Render Widget / Frontend
        public function widget( $args, $instance ) { ?>

            <div class="welearner-counter">
                <div class="container">
                    <div class="row">
                        
                        <?php 
                        // Variable defind
                        $inputbox = isset( $instance['inputbox'] ) ? $instance["inputbox"] : '';

                        for( $i=1; $i<=$inputbox; $i++ ) { 
                            
                            $number = isset( $instance["number$i"] ) ? $instance["number$i"] : '' ;
                            $desc = isset( $instance["desc$i"] ) ? $instance["desc$i"] : '' ;

                            ?>
                            <div class="col-lg-4">
                                <div class="single-counter">								
                                    <?php if( $number ): ?><h2 class="number"><?php echo wp_kses( $number, 'allowed_html' ); ?></h2><?php endif; ?>
                                    <?php if( $desc ): ?><p class="desc"><?php echo wp_kses( $desc, 'allowed_html' ); ?></p><?php endif; ?>								
                                </div>
                            </div>
                        <?php } ?>
                        
                    </div>
                </div>
            </div>

        <?php	
        }    
        
        // Update inputed data
        public function update( $new_instance, $old_instance ) {  
            return $new_instance;
        }
        
        // Back-end Fields
        public function form( $instance ) {

            $inputbox = isset( $instance['inputbox'] ) ? $instance["inputbox"] : ''; ?>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>"><b><?php esc_html_e( "How many counter would you want? & hit enter.","welearner" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "inputbox" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" type="text" value="<?php echo esc_attr( $inputbox ); ?>" />
            </p>

            <?php
            
            for( $i=1; $i<=$inputbox; $i++ ) {

                // Variable defind     
                $number = isset( $instance["number$i"] ) ? $instance["number$i"] : '' ;
                $desc = isset( $instance["desc$i"] ) ? $instance["desc$i"] : '' ;         

                ?>  
                <!-- fields -->	
                <p><b><?php esc_html_e( "Number $i", "welearner" ); ?></b><hr/></p>		
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "number$i" ) ); ?>"><?php echo esc_html( 'Number', 'welearner' ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "number$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "number$i" ) ); ?>" type="text" value="<?php echo esc_attr( $number ); ?>" />
                </p>
                <p>
                    <label for="<?php echo $this->get_field_id("desc$i"); ?>"><?php esc_html_e( 'Description', 'welearner' ); ?></label><br />
                    <textarea name="<?php echo $this->get_field_name("desc$i"); ?>" id="<?php echo $this->get_field_id("desc$i"); ?>" class="widefat"><?php echo $instance["desc$i"]; ?></textarea>
                </p>
                
            <?php 
            }			
        }
    }

    /**
     * Client logo section
     */
    class welearnerClient extends WP_Widget{    
            
        public function __construct() {
            $widget_details = array(
                'classname' => 'welearnerClient',
                'description' => esc_html__( 'Client logo section element.','welearner' )
            );
            parent::__construct( 'welearnerClient', esc_html__( '&#9733; Client Logo Section','welearner' ) , $widget_details );
        }
    
        // Render Widget / Frontend
        public function widget( $args, $instance ) { 	
            
            // Variable defind
            $title = isset( $instance['title'] ) ? $instance['title']: ''; 
            $inputbox = isset( $instance['inputbox'] ) ? $instance["inputbox"] : '' ; ?>

            <div class="welearner-client">
                <div class="container">
                    <div class="row d-flex justify-content-center">
                        <div class="col-lg-12 section-header">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="welearner-title">
                                        <?php echo wp_kses( $title, 'allowed_html' ); ?>
                                    </div>
                                </div>							
                            </div>
                        </div>

                        <?php for( $i=1; $i<=$inputbox; $i++ ) { 
                            $image_uri = isset( $instance["image_uri$i"] ) ? $instance["image_uri$i"] : '' ; 
                            ?>
                            <div class="single-logo">
                                <img src="<?php echo esc_url($image_uri); ?>" alt="<?php echo esc_attr($image_uri); ?>">
                            </div>
                        <?php } ?>				
                        
                    </div>
                </div>
            </div>

        <?php	
        }    
        
        // Update inputed data
        public function update( $new_instance, $old_instance ) {  
            return $new_instance;
        }
        
        // Back-end Fields
        public function form( $instance ) {

            // Variable defind
            $title = isset( $instance['title'] ) ? $instance['title']: ''; 
            $inputbox = isset( $instance['inputbox'] ) ? $instance["inputbox"] : '' ; ?>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>"><b><?php esc_html_e( "Title","welearner" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "title" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>"><b><?php esc_html_e( "How many field would you want? & hit enter.","welearner" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "inputbox" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" type="text" value="<?php echo esc_attr( $inputbox ); ?>" />
            </p>

            <?php
            
            for( $i=1; $i<=$inputbox; $i++ ) {

                // Variable defind
                $image_uri = isset( $instance["image_uri$i"] ) ? $instance["image_uri$i"] : '' ;  ?>  
                <!-- Member fields -->						
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_id( "image_uri$i" )); ?>"><?php esc_html_e( 'Client logo', 'welearner' ); ?></label>
                    <img class="<?php echo esc_attr( $this->id.$i ); ?>_img" src="<?php echo esc_url( $image_uri ); ?>" />
                    <input type="text" class="widefat <?php echo esc_attr( $this->id.$i ); ?>_url" name="<?php echo esc_attr( $this->get_field_name( "image_uri$i" )); ?>" value="<?php echo esc_attr( $instance["image_uri$i"] ); ?>" />
                    <input type="button" id="<?php echo esc_attr( $this->id.$i ); ?>" class="button button-primary js_custom_upload_media" value="<?php esc_html_e( 'Upload Image', 'welearner' ); ?>" />
                </p>
                        
            <?php 
            }			
        }
    }

    /**
     * Footer about section
     */
    class welearnerAbout extends WP_Widget{    
            
        public function __construct() {
            $widget_details = array(
                'classname' => 'welearnerAbout',
                'description' => esc_html__( 'Footer about section element.','welearner' )
            );
            parent::__construct( 'welearnerAbout', esc_html__( '&#9733; Footer About Section','welearner' ) , $widget_details );
        }
    
        // Render Widget / Frontend
        public function widget( $args, $instance ) { 
            
            // Variable defind
            $grid = isset( $instance['grid'] ) ? $instance['grid']: 4; 
            $desc = isset( $instance['desc'] ) ? $instance["desc"] : '';
            $inputbox = isset( $instance['inputbox'] ) ? $instance["inputbox"] : '';
            $image_uri = isset( $instance['image_uri'] ) ? $instance["image_uri"] : '';

            ?>
                        
            <div class="footer-about col-lg-<?php echo esc_attr( $grid ); ?>">
                
                <?php 

                if ( $image_uri ) {
                    echo '<img src="' . esc_url( $image_uri ) . '" class="company-logo" alt="' . get_bloginfo( 'name' ) . '">';
                } else {
                    echo '<h3>'. get_bloginfo( 'name' ) .'</h3>';
                }
                
                ?>

                <?php if( $desc ): ?><p class="desc"><?php echo wp_kses( $desc, 'allowed_html' ); ?></p><?php endif; ?>						
                <?php for( $i=1; $i<=$inputbox; $i++ ) { 
                    
                    // Variable defind
                    $icon_class = isset( $instance["icon_class$i"] ) ? $instance["icon_class$i"] : '' ;
                    $social_url = isset( $instance["social_url$i"] ) ? $instance["social_url$i"] : '' ; 

                    ?>							
                    <ul class="single-social">								
                        <?php if( $social_url ): ?><li><a href="<?php echo esc_url( $social_url ); ?>" class="icon-class"><i class="<?php echo esc_attr( $icon_class ); ?>"></i></a></li><?php endif; ?>								
                    </ul>							
                <?php } ?>
            </div>

        <?php	
        }    
        
        // Update inputed data
        public function update( $new_instance, $old_instance ) {  
            return $new_instance;
        }
        
        // Back-end Fields
        public function form( $instance ) {

            // Variable defind
            $grid = isset( $instance['grid'] ) ? $instance['grid']: 4; 
            $desc = isset( $instance['desc'] ) ? $instance["desc"] : '';
            $inputbox = isset( $instance['inputbox'] ) ? $instance["inputbox"] : '';
            $image_uri = isset( $instance['image_uri'] ) ? $instance["image_uri"] : ''; ?>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "grid" ) ); ?>"><b><?php esc_html_e( "Select Grid","welearner" ); ?></b></label>            
                <select class="widefat" id="<?php echo esc_attr( $this->get_field_id( "grid" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "grid" ) ); ?>">
                    <option value="2" <?php if( $grid == 2 ): echo "selected"; endif; ?> ><?php esc_html_e( '2 Colomn Grid','welearner' ); ?></option>
                    <option value="3" <?php if( $grid == 3 ): echo "selected"; endif; ?>><?php esc_html_e( '3 Colomn Grid','welearner' ); ?></option>
                    <option value="4" <?php if( $grid == 4 ): echo "selected"; endif; ?> ><?php esc_html_e( '4 Colomn Grid','welearner' ); ?></option>
                    <option value="6" <?php if( $grid == 6 ): echo "selected"; endif; ?> ><?php esc_html_e( '6 Colomn Grid','welearner' ); ?></option>
                </select>
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_id( "image_uri" )); ?>"><?php esc_html_e( 'Client logo', 'welearner' ); ?></label>
                <img class="<?php echo esc_attr( $this->id ); ?>_img" src="<?php echo esc_url( $image_uri ); ?>" />
                <input type="text" class="widefat <?php echo esc_attr( $this->id ); ?>_url" name="<?php echo esc_attr( $this->get_field_name( "image_uri" )); ?>" value="<?php echo esc_attr( $image_uri ); ?>" />
                <input type="button" id="<?php echo esc_attr( $this->id ); ?>" class="button button-primary js_custom_upload_media" value="<?php esc_html_e( 'Upload Image', 'welearner' ); ?>" />
            </p>
            <p>
                <label for="<?php echo $this->get_field_id('desc'); ?>"><?php esc_html_e( 'Description', 'welearner' ); ?></label><br />
                <textarea name="<?php echo $this->get_field_name('desc'); ?>" id="<?php echo $this->get_field_id('desc'); ?>" class="widefat"><?php echo wp_kses( $desc, 'allowed_html' ); ?></textarea>
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>"><b><?php esc_html_e( "How many social field would you want? & hit enter.","welearner" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "inputbox" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" type="text" value="<?php echo esc_attr( $inputbox ); ?>" />
            </p>

            <?php
            
            for( $i=1; $i<=$inputbox; $i++ ) {

                // Variable defind     
                $icon_class = isset( $instance["icon_class$i"] ) ? $instance["icon_class$i"] : '' ;
                $social_url = isset( $instance["social_url$i"] ) ? $instance["social_url$i"] : '' ;         

                ?>  
                <!-- fields -->	
                <p><b><?php esc_html_e( "Social $i", "welearner" ); ?></b><hr/></p>		
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "icon_class$i" ) ); ?>"><?php echo esc_html( 'Icon Class EX: https://icons8.com/line-awesome', 'welearner' ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "icon_class$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "icon_class$i" ) ); ?>" type="text" value="<?php echo esc_attr( $icon_class ); ?>" />
                </p>
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "social_url$i" ) ); ?>"><?php echo esc_html( 'Social URL', 'welearner' ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "social_url$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "social_url$i" ) ); ?>" type="text" value="<?php echo esc_attr( $social_url ); ?>" />
                </p>
                
            <?php 
            }			
        }
    }

    /**
     * Footer link section
     */
    class welearnerFooterLink extends WP_Widget{    
            
        public function __construct() {
            $widget_details = array(
                'classname' => 'welearnerFooterLink',
                'description' => esc_html__( 'Footer link section element.','welearner' )
            );
            parent::__construct( 'welearnerFooterLink', esc_html__( '&#9733; Footer Link Section','welearner' ) , $widget_details );
        }
    
        // Render Widget / Frontend
        public function widget( $args, $instance ) { 
            
            // Variable defind
            $grid = isset( $instance['grid'] ) ? $instance['grid']: 2; 
            $inputbox = isset( $instance['inputbox'] ) ? $instance["inputbox"] : '';
            $title = isset( $instance['title'] ) ? $instance["title"] : '';

            ?>
                        
            <div class="footer-link col-lg-<?php echo esc_attr( $grid ); ?>">			
                <?php if( $title ): ?><h3 class="title"><?php echo wp_kses( $title, 'allowed_html' ); ?></h3><?php endif; ?>			
                <?php for( $i=1; $i<=$inputbox; $i++ ) { 
                    
                    // Variable defind
                    $link_text = isset( $instance["link_text$i"] ) ? $instance["link_text$i"] : '';
                    $link_url = isset( $instance["link_url$i"] ) ? $instance["link_url$i"] : '';  

                    ?>							
                    <ul class="single-link">								
                        <?php if( $link_url ): ?><li><a href="<?php echo esc_url( $link_url ); ?>" class="link-url"><?php echo esc_attr( $link_text ); ?></a></li><?php endif; ?>								
                    </ul>							
                <?php } ?>
            </div>

        <?php	
        }    
        
        // Update inputed data
        public function update( $new_instance, $old_instance ) {  
            return $new_instance;
        }
        
        // Back-end Fields
        public function form( $instance ) {

            // Variable defind
            $grid = isset( $instance['grid'] ) ? $instance['grid']: 2; 
            $inputbox = isset( $instance['inputbox'] ) ? $instance["inputbox"] : '';
            $title = isset( $instance['title'] ) ? $instance["title"] : ''; ?>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "grid" ) ); ?>"><b><?php esc_html_e( "Select Grid","welearner" ); ?></b></label>            
                <select class="widefat" id="<?php echo esc_attr( $this->get_field_id( "grid" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "grid" ) ); ?>">
                    <option value="2" <?php if( $grid == 2 ): echo "selected"; endif; ?> ><?php esc_html_e( '2 Colomn Grid','welearner' ); ?></option>
                    <option value="3" <?php if( $grid == 3 ): echo "selected"; endif; ?>><?php esc_html_e( '3 Colomn Grid','welearner' ); ?></option>
                    <option value="4" <?php if( $grid == 4 ): echo "selected"; endif; ?> ><?php esc_html_e( '4 Colomn Grid','welearner' ); ?></option>
                    <option value="6" <?php if( $grid == 6 ): echo "selected"; endif; ?> ><?php esc_html_e( '6 Colomn Grid','welearner' ); ?></option>
                </select>
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>"><b><?php esc_html_e( "Title","welearner" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "title" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>"><b><?php esc_html_e( "How many social field would you want? & hit enter.","welearner" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "inputbox" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" type="text" value="<?php echo esc_attr( $inputbox ); ?>" />
            </p>

            <?php
            
            for( $i=1; $i<=$inputbox; $i++ ) {

                // Variable defind     
                $link_text = isset( $instance["link_text$i"] ) ? $instance["link_text$i"] : '';
                $link_url = isset( $instance["link_url$i"] ) ? $instance["link_url$i"] : '';         

                ?>  
                <!-- fields -->	
                <p><b><?php esc_html_e( "Link $i", "welearner" ); ?></b><hr/></p>		
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>"><?php echo esc_html( 'Link Text', 'welearner' ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "link_text$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>" type="text" value="<?php echo esc_attr( $link_text ); ?>" />
                </p>
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>"><?php echo esc_html( 'Link URL', 'welearner' ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "link_url$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>" type="text" value="<?php echo esc_attr( $link_url ); ?>" />
                </p>
                
            <?php 
            }			
        }
    }

    /**
     * Popular topics section
     */
    class welearnerPopularTopics extends WP_Widget {
        
        public function __construct(){
            $widget_details = array(
                'classname' => 'welearnerPopularTopics',
                'description' => esc_html__( 'Popular topics element.','welearner' )
            );
            parent::__construct( 'welearnerPopularTopics', esc_html__( '&#9733; Popular Topics Section','welearner' ) , $widget_details );
        }

        // Render Widget / Frontend
        function widget($args, $instance) { 
            
            // Variable defind
            $title = isset( $instance['title'] ) ? $instance['title']: '';
            $btn_text = isset( $instance['btn_text'] ) ? $instance['btn_text']: ''; 
            $btn_url = isset( $instance['btn_url'] ) ? $instance['btn_url']: '';
            
            ?>
            
            <div class="welearner-popular-topics">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="popular-topics-header">
                                <div class="welearner-title">
                                    <?php echo wp_kses( $title, 'allowed_html' ); ?>
                                </div>					
                                <div class="welearner-all-button">
                                    <?php if( $btn_text ): ?><a href="<?php echo esc_url($btn_url); ?>"><?php echo esc_html($btn_text); ?></a><?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php
                        // Get all topics	
                        $terms = get_terms( 'course-topic' );
                        if ( !empty( $terms ) && ! is_wp_error( $terms ) ){
                            foreach ( $terms as $term ) { 
                                
                                // Variable defind
                                $term_icon_class = get_term_meta( $term->term_id, 'term_icon_class', true );
                                $icon_bg = get_term_meta( $term->term_id, 'icon_bg', true );
                                $icon_color = get_term_meta( $term->term_id, 'icon_color', true );
                                
                                ?>							
                                <div class="col-lg-3">
                                    <div class="single-topic">
                                        <?php if( $term_icon_class ): ?>
                                            <div class="cat-icon"><i style="<?php printf( 'background: %s; color: %s;', $icon_bg, $icon_color ); ?>" class="<?php echo esc_attr( $term_icon_class ); ?>"></i></div>
                                        <?php endif; ?>
                                        <div class="cat-url">
                                            <h2><a href="<?php echo esc_url( get_term_link( $term ) ); ?>"><?php echo esc_html( $term->name ); ?></a></h2>
                                        </div>

                                    </div>
                                </div>
                            <?php
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>

        <?php
        }

        function update($new_instance, $old_instance) {
            $instance = $old_instance;
            $instance['title'] =  $new_instance['title'] ;
            $instance['btn_text'] =  $new_instance['btn_text'] ;
            $instance['btn_url'] = $new_instance['btn_url'];
            return $instance;
        }

        // Back-end Fields
        function form($instance) { 
            
            // Variable defind
            $title = isset( $instance['title'] ) ? $instance['title']: '';
            $btn_text = isset( $instance['btn_text'] ) ? $instance['btn_text']: ''; 
            $btn_url = isset( $instance['btn_url'] ) ? $instance['btn_url']: ''; 
            
            ?>

            <p>
                <label for="<?php echo $this->get_field_id('title'); ?>"><?php esc_html_e( 'Title', 'welearner' ); ?></label><br />
                <input type="text" name="<?php echo $this->get_field_name('title'); ?>" id="<?php echo $this->get_field_id('title'); ?>" value="<?php echo wp_kses( $title, 'allowed_html' ); ?>" class="widefat" />
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "btn_text" ) ); ?>"><?php echo esc_html( 'Button Text', 'welearner' ); ?></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "btn_text" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "btn_text" ) ); ?>" type="text" value="<?php echo esc_attr( $btn_text ); ?>" />
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "btn_url" ) ); ?>"><?php echo esc_html( 'Button URL', 'welearner' ); ?></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "btn_url" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "btn_url" ) ); ?>" type="text" value="<?php echo esc_attr( $btn_url ); ?>" />
            </p>

        <?php
        }
    }

    /**
     * Courses section
     */
    class welearnerCourse extends WP_Widget{    
            
        public function __construct() {
            $widget_details = array(
                'classname' => 'welearnerCourse',
                'description' => esc_html__( 'Course section element.','welearner' )
            );
            parent::__construct( 'welearnerCourse', esc_html__( '&#9733; Course Section','welearner' ) , $widget_details );
        }
    
        // Render Widget / Frontend
        public function widget( $args, $instance ) { 

            global $post;

            // Variable defind
            $title = isset( $instance['title'] ) ? $instance['title']: ''; 
            $course_select = isset( $instance['course_select'] ) ? $instance['course_select']: 1; 
            $btn_text = isset( $instance['btn_text'] ) ? $instance['btn_text']: 1; 
            $btn_url = isset( $instance['btn_url'] ) ? $instance['btn_url']: 1; 
            $max_post = isset( $instance['max_post'] ) ? $instance['max_post']: 1; 

            // Latest posts
            if( $course_select == 1 ) {
                $course = new WP_Query( 
                    array( 
                        'posts_per_page' => $max_post, 
                        'post_type' => 'course', 
                        'order' => 'DESC',
                        'post__not_in' => get_option( 'sticky_posts' )
                    ) 
                );

            } else if( $course_select == 2 ) {

                // Top rated posts
                $course = new WP_Query( 
                    array( 
                        'posts_per_page' => $max_post, 
                        'post_type' => 'course',
                        'meta_key' => 'ratings',
                        'orderby' => 'meta_value_num',
                        'meta_type' => 'DATE',
                        'order' => 'DESC',
                        'post__not_in' => get_option( 'sticky_posts' )
                    ) 
                );

            }
                
            ?>

            <div class="welearner-course">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="popular-topics-header">
                                <div class="welearner-title">
                                    <?php echo wp_kses( $title, 'allowed_html' ); ?>
                                </div>					
                                <div class="welearner-all-button">
                                    <?php if( $btn_text ): ?><a href="<?php echo esc_url($btn_url); ?>"><?php echo esc_html($btn_text); ?></a><?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <?php  //SHOW the posts
                        
                        if( $course -> have_posts() ) :
                            while ( $course -> have_posts() ): $course -> the_post(); ?>                        
                                
                            <div class="col-lg-4">
                                <div class="single-post">
                                    <?php the_post_thumbnail( '', [ 'class' => 'home-thumbnail' ] ) ?>
                                    <div class="course-title-top">
                                        <div class="course-cat">
                                            WordPress
                                        </div>
                                        <div class="course-rating">
                                            <?php 
                                            $ratings = get_post_meta( $post->ID, 'ratings', true ); 

                                            if( $ratings == 1 ) {
                                                echo '<i class="las la-star"></i>';
                                            } else if( $ratings == 2 ) {
                                                echo '<i class="las la-star"></i><i class="las la-star"></i>';
                                            } else if( $ratings == 3 ) {
                                                echo '<i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i>';
                                            } else if( $ratings == 4 ) {
                                                echo '<i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i>';
                                            } else if( $ratings == 5 ) {
                                                echo '<i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i>';
                                            }									
                                            
                                            ?>								
                                        </div>								
                                    </div>
                                    <h2 class="course-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                                    <?php echo get_avatar( get_the_author_meta('ID'), 30, '', '', array('class' => array('course-author'))); ?> <a href="<?php echo get_author_posts_url( get_the_author_meta('ID')); ?>" class="author-name"> <?php the_author(); ?></a>
                                    
                                    <div class="course-foot">
                                        <span class="price">
                                            <del><?php echo "$". get_post_meta( $post->ID, 'sale_price', true ); ?></del>
                                            <?php echo "$". get_post_meta( $post->ID, 'price', true ); ?>
                                        </span>
                                        <span><a href="<?php echo get_post_meta( $post->ID, 'btn_url', true ); ?>" class="btn-preview"><?php echo get_post_meta( $post->ID, 'btn_text', true ); ?></a></span>
                                    </div>
                                    
                                </div>
                            </div>
                                
                            <?php          
                            endwhile;
                            wp_reset_postdata();
                        else:
                            echo "<br>";
                            esc_html_e( 'There has post.','welearner' );                     
                        endif; ?>
                                                
                    </div>
                </div>
            </div>

        <?php	
        }    
        
        // Update inputed data
        public function update( $new_instance, $old_instance ) {  
            return $new_instance;
        }
        
        // Back-end Fields
        public function form( $instance ) {

            // Variable defind
            $title = isset( $instance['title'] ) ? $instance['title']: ''; 
            $max_post = isset( $instance['max_post'] ) ? $instance["max_post"] : 3 ;
            $btn_text = isset( $instance['btn_text'] ) ? $instance["btn_text"] : '' ;
            $btn_url = isset( $instance['btn_url'] ) ? $instance["btn_url"] : '' ;
            $course_select = isset( $instance['course_select'] ) ? $instance['course_select']: 1; 

            ?>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>"><b><?php esc_html_e( "Title","welearner" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "title" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
            </p>		
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "max_post" ) ); ?>"><b><?php esc_html_e( "How many post would you want? & hit save.","welearner" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "max_post" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "max_post" ) ); ?>" type="text" value="<?php echo esc_attr( $max_post ); ?>" />
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "btn_text" ) ); ?>"><?php echo esc_html( 'Button Text', 'welearner' ); ?></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "btn_text" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "btn_text" ) ); ?>" type="text" value="<?php echo esc_attr( $btn_text ); ?>" />
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "btn_url" ) ); ?>"><?php echo esc_html( 'Button URL', 'welearner' ); ?></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( "btn_url" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "btn_url" ) ); ?>" type="text" value="<?php echo esc_attr( $btn_url ); ?>" />
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "course_select" ) ); ?>"><b><?php esc_html_e( "Select Course Type","welearner" ); ?></b></label>            
                <select class="widefat" id="<?php echo esc_attr( $this->get_field_id( "course_select" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "course_select" ) ); ?>">
                    <option value="1" <?php if( $course_select == 1 ): echo "selected"; endif; ?> ><?php esc_html_e( 'Latest Course','welearner' ); ?></option>
                    <option value="2" <?php if( $course_select == 2 ): echo "selected"; endif; ?>><?php esc_html_e( 'Top Rated Course','welearner' ); ?></option>
                </select>
            </p>

            <?php		
        }
    }

    // Register widget
    register_widget( 'welearnerHero' );
    register_widget( 'welearnerTestimonial' );
    register_widget( 'welearnerTeamMember' );
    register_widget( 'welearnerBlog' );
    register_widget( 'welearnerCta' );
    register_widget( 'welearnerCounter' );
    register_widget( 'welearnerClient' );
    register_widget( 'welearnerAbout' );
    register_widget( 'welearnerFooterLink' );
    register_widget( 'welearnerPopularTopics' );
    register_widget( 'welearnerCourse' );

}
add_action( 'widgets_init', 'welearner_widgets_init' );