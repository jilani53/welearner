<?php
/**
 * Metabox
 *
 * @package Welearner
 */

/**
 * Course meta box class
 */
class WelearnerCourseMetabox {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'welearner_add_metabox' ) );
		add_action( 'save_post', array( $this, 'welearner_save_course' ) );

		// Course topic term meta actions
		add_action( 'init', array( $this, 'welearner_term_meta_filed' ) );
		add_action( 'course-topic_add_form_fields', array( $this, 'welearner_render_field' ) );
		add_action( 'course-topic_edit_form_fields', array( $this, 'welearner_edit_term_field' ) );
		add_action( 'create_course-topic', array( $this, 'welearner_save_term_field_value' ) );
		add_action( 'edit_course-topic', array( $this, 'welearner_update_term_field_value' ) );
	}

	// Security checker before save post meta
	private function is_secured( $nonce_field, $action, $post_id ) {
		$nonce = isset( $_POST[ $nonce_field ] ) ? $_POST[ $nonce_field ] : '';

		if ( $nonce == '' ) {
			return false;
		}
		if ( ! wp_verify_nonce( $nonce, $action ) ) {
			return false;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return false;
		}

		if ( wp_is_post_autosave( $post_id ) ) {
			return false;
		}

		if ( wp_is_post_revision( $post_id ) ) {
			return false;
		}

		return true;

	}

	// Save post meta
	function welearner_save_course( $post_id ) {

		// Return invalid data
		if ( ! $this->is_secured( 'welearner_course_field', 'welearner_course_nonce', $post_id ) ) {
			return $post_id;
		}

		$price = isset( $_POST['price'] ) ? $_POST['price'] : '';
		$sale_price  = isset( $_POST['sale_price'] ) ? $_POST['sale_price'] : '';
		$btn_text  = isset( $_POST['btn_text'] ) ? $_POST['btn_text'] : '';
		$btn_url  = isset( $_POST['btn_url'] ) ? $_POST['btn_url'] : '';
		$ratings      = isset( $_POST['ratings'] ) ? $_POST['ratings'] : '';

		if ( $price == '' || $sale_price == '' || $btn_text == '' || $btn_url == '' || $ratings == '' ) {
			return $post_id;
		}

		$price = sanitize_text_field($price);
		$sale_price = sanitize_text_field($sale_price);
		$btn_text = sanitize_text_field($btn_text);
		$btn_url = sanitize_text_field($btn_url);
		$ratings = sanitize_text_field($ratings);

		update_post_meta( $post_id, 'price', $price );
		update_post_meta( $post_id, 'sale_price', $sale_price );
		update_post_meta( $post_id, 'btn_text', $btn_text );
		update_post_meta( $post_id, 'btn_url', $btn_url );
		update_post_meta( $post_id, 'ratings', $ratings );
	}

	function welearner_add_metabox() {
		add_meta_box(
			'welearner_course',
			__( 'Course Info', 'welearner' ),
			[ $this, 'welearner_display_course' ],
			['course']
		);
	}

	// Rander course post meta fileds
	function welearner_display_course( $post ) {
		
		wp_nonce_field( 'welearner_course_nonce', 'welearner_course_field' );

		$price = get_post_meta( $post->ID, 'price', true );
		$sale_price  = get_post_meta( $post->ID, 'sale_price', true );
		$btn_text  = get_post_meta( $post->ID, 'btn_text', true );
		$btn_url  = get_post_meta( $post->ID, 'btn_url', true );
		$ratings = get_post_meta( $post->ID, 'ratings', true );	

		?>

		<table class="form-table">
			<tbody>

				<tr>
					<th><label for="price"><?php esc_html_e( 'Price:', 'welearner' ); ?></label></th>
					<td><input type="text" class="regular-text code" name="price" id="price" value="<?php echo esc_attr( $price ); ?>"/></td>
				</tr>
				<tr>
					<th><label for="sale_price"><?php esc_html_e( 'Sale price:', 'welearner' ); ?></label></th>
					<td><input type="text" class="regular-text code" name="sale_price" id="sale_price" value="<?php echo esc_attr( $sale_price ); ?>"/></td>
				</tr>
				<tr>
					<th><label for="btn_text"><?php esc_html_e( 'Course Preview:', 'welearner' ); ?></label></th>
					<td><input type="text" class="regular-text code" name="btn_text" id="btn_text" value="<?php echo esc_attr( $btn_text ); ?>"/></td>
				</tr>
				<tr>
					<th><label for="btn_url"><?php esc_html_e( 'Course Preview URL:', 'welearner' ); ?></label></th>
					<td><input type="text" class="regular-text code" name="btn_url" id="btn_url" value="<?php echo esc_attr( $btn_url ); ?>"/></td>
				</tr>
				<tr>
					<th><label for="btn_url"><?php esc_html_e( 'Ratings:', 'welearner' ); ?></label></th>
					<td>
						<select name="ratings" id="ratings" class="regular-text">
							<option value="0"><?php esc_html_e( 'Ratings', 'welearner' ); ?></option>
							<?php 
							$ratings_value = [ '1' => '1 Star',  '2' => '2 Star', '3' => '3 Star', '4' => '4 Star', '5' => '5 Star' ];
							$ratings = get_post_meta( $post->ID, 'ratings', true );
							foreach( $ratings_value as $key => $value ) {
								$selected = '';
								if( $key == $ratings ) {
									$selected = 'selected';
								}
								printf( "<option value='%s' %s>%s</option>", $key, $selected, $value );			
							} ?>
						</select>
					</td>
				</tr>
				
			</tbody>
		</table>
	<?php 
	}
	
	/**
	 * Course topic term meta fileds
	 */
	function welearner_term_meta_filed () {
		$args = [
			'type'              => 'string',
			'sanitize_callback' => 'sanitize_text_field',
			'single'            => true,
			'description'       => 'sample meta field for category tax',
			'show_in_rest'      => true
		];
		register_meta( 'term', 'term_icon_class', $args );
	}

	// Render term fileds
	function welearner_render_field() {
		?>
		<div class="form-field form-required term-name-wrap">
			<label for="tag-name"><?php _e( 'Input term icon class <br>Ex: las la-layer-group', 'welearner' ); ?></label>
			<input name="term-icon-class" id="term-icon-class" type="text" value="" size="40" aria-required="false">
			<p><?php _e( 'You can get icon class from here https://icons8.com/line-awesome', 'welearner' ); ?></p>
		</div>
		<div class="form-field form-required term-name-wrap">
			<label for="icon_bg"><?php _e( 'Background color', 'welearner' ); ?></label>
			<input name="icon_bg" id="icon_bg" type="color" value="" size="40" aria-required="false">
			<p><?php _e( 'Term icon background color.', 'welearner' ); ?></p>
		</div>
		<div class="form-field form-required term-name-wrap">
			<label for="icon_color"><?php _e( 'Icon color', 'welearner' ); ?></label>
			<input name="icon_color" id="icon_color" type="color" value="" size="40" aria-required="false">
			<p><?php _e( 'Term icon color.', 'welearner' ); ?></p>
		</div>
		<?php
	}

	// Edit term field
	function welearner_edit_term_field( $term ) {
		$term_icon_class = get_term_meta( $term->term_id, 'term_icon_class', true );
		$icon_bg = get_term_meta( $term->term_id, 'icon_bg', true );
		$icon_color = get_term_meta( $term->term_id, 'icon_color', true );
		?>
		<tr class="form-field form-required term-name-wrap">
			<th scope="row">
				<label for="tag-name">
					<?php _e( 'Input term icon class <br>Ex: las la-layer-group', 'welearner' ); ?>
				</label>
			</th>
			<td>
				<input name="term-icon-class" id="term-icon-class" type="text" value="<?php echo esc_attr( $term_icon_class ); ?>" size="40" aria-required="true">
				<p><?php _e( 'You can get icon class from here https://icons8.com/line-awesome', 'welearner' ); ?></p>
			</td>
		</tr>
		<tr class="form-field form-required term-name-wrap">
			<th scope="row">
				<label for="icon_bg">
					<?php _e( 'Background color', 'welearner' ); ?>
				</label>
			</th>
			<td>
				<input name="icon_bg" id="icon_bg" type="color" value="<?php echo esc_attr( $icon_bg ); ?>" size="40" aria-required="true">
				<p><?php _e( 'Term icon background color.', 'welearner' ); ?></p>
			</td>
		</tr>
		<tr class="form-field form-required term-name-wrap">
			<th scope="row">
				<label for="icon_color">
					<?php _e( 'Icon color', 'welearner' ); ?>
				</label>
			</th>
			<td>
				<input name="icon_color" id="icon_color" type="color" value="<?php echo esc_attr( $icon_color ); ?>" size="40" aria-required="true">
				<p><?php _e( 'Term icon color.', 'welearner' ); ?></p>
			</td>
		</tr>
		<?php
	}

	// Save term fileds value
	function welearner_save_term_field_value ( $term_id ) {
		if ( wp_verify_nonce( $_POST['_wpnonce_add-tag'], 'add-tag' ) ) {
			$term_icon_class = sanitize_text_field( $_POST['term-icon-class'] );
			$icon_bg = sanitize_text_field( $_POST['icon_bg'] );
			$icon_color = sanitize_text_field( $_POST['icon_color'] );
			update_term_meta( $term_id, 'term_icon_class', $term_icon_class );
			update_term_meta( $term_id, 'icon_bg', $icon_bg );
			update_term_meta( $term_id, 'icon_color', $icon_color );
		}
	}

	// Update term field value
	function welearner_update_term_field_value ( $term_id ) {
		if ( wp_verify_nonce( $_POST['_wpnonce'], "update-tag_{$term_id}" ) ) {
			$term_icon_class = sanitize_text_field( $_POST['term-icon-class'] );
			$icon_bg = sanitize_text_field( $_POST['icon_bg'] );
			$icon_color = sanitize_text_field( $_POST['icon_color'] );
			update_term_meta( $term_id, 'term_icon_class', $term_icon_class );
			update_term_meta( $term_id, 'icon_bg', $icon_bg );
			update_term_meta( $term_id, 'icon_color', $icon_color );
		}
	}
}
new WelearnerCourseMetabox();




