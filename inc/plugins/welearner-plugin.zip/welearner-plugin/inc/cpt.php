<?php
/**
 * Custom post type
 *
 * @package Welearner
 */
 
/**
 * Register custom post type
 * @course
 */
function welearner_cpt_course() {

	/**
	 * Post Type: Courses.
	 */

	$labels = [
		"name"                  => __( "Courses", "welearner" ),
		"singular_name"         => __( "Course", "welearner" ),
		"add_new" 				=> __( "Add New Course", "welearner" ),
		"featured_image"        => __( "Course Cover", "welearner" ),
		"set_featured_image"    => __( "Set Course Cover Image", "welearner" ),
		"remove_featured_image" => __( "Remove Course Cover Image", "welearner" ),
		"use_featured_image"    => __( "Use Course Cover Image", "welearner" ),
	];

	$args = [
		"label"                 => __( "Courses", "welearner" ),
		"labels"                => $labels,
		"menu_icon"             => "dashicons-welcome-learn-more",
		"public"                => true,
		"publicly_queryable"    => true,
		"show_ui"               => true,
		"show_in_rest"          => true,
		"has_archive"           => true,
		"show_in_menu"          => true,
		"show_in_nav_menus"     => true,
		"delete_with_user"      => false,
		"exclude_from_search"   => false,
		"map_meta_cap"          => true,
		"hierarchical"          => false,
		"rewrite"               => ["slug" => "course", "with_front" => true],
		"query_var"             => true,
		"supports"              => ["title", "editor", "thumbnail"],
	];
	register_post_type( "course", $args );
}
add_action( 'init', 'welearner_cpt_course' );

/**
 * Register custom taxonomy
 * @course-topic
 */
function welearner_course_taxonomy() {
	$labels = [
		'name'              => __( 'Course Topics', 'welearner' ),
		'singular_name'     => __( 'Course Topic', 'welearner' ),
		'search_items'      => __( 'Search Course Topics', 'welearner' ),
		'all_items'         => __( 'All Course Topics', 'welearner' ),
		'parent_item'       => __( 'Parent Course Topic', 'welearner' ),
		'parent_item_colon' => __( 'Parent Course Topic:', 'welearner' ),
		'edit_item'         => __( 'Edit Course Topic', 'welearner' ),
		'update_item'       => __( 'Update Course Topic', 'welearner' ),
		'add_new_item'      => __( 'Add New Course Topic', 'welearner' ),
		'new_item_name'     => __( 'New Course Topic Name', 'welearner' ),
		'menu_name'         => __( 'Course Topics', 'welearner' ),
	];
	$args   = [
		'hierarchical'      => true,
		'labels'            => $labels,
		'show_ui'           => true,
		'show_in_rest'      => true,
		'show_admin_column' => true,
		'query_var'         => true
	];
	register_taxonomy( 'course-topic', [ 'course' ], $args );
}
add_action( 'init', 'welearner_course_taxonomy' );



